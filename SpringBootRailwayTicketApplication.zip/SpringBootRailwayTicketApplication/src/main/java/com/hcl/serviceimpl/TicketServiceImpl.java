package com.hcl.serviceimpl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.exception.TicketNotBookedException;
import com.hcl.model.Booking;
import com.hcl.model.Passengers;
import com.hcl.model.Train;
import com.hcl.model.User;
import com.hcl.repository.TicketRepository;
import com.hcl.repository.TrainRepository;
import com.hcl.repository.UserRepository;
import com.hcl.service.TicketService;

@Service
public class TicketServiceImpl implements TicketService {

	@Autowired
	TicketRepository ticketRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	TrainRepository trainRepository;

	@Override
	public String bookingTicket(int userId, int trainId, List<Passengers> passengers) throws TicketNotBookedException {

		Train train = new Train();
		User user = new User();

		train = trainRepository.findByTrainId(trainId);
		user = userRepository.findByUserId(userId);

		if (train != null && user != null) {

			Booking booking = new Booking();
			booking.setUser(user);
			booking.setTrain(train);
			booking.setDate(new Date());

			// for(Passengers passenger :passengers) {
			// if(passenger.getAdhaarNumber() !=0) {
			// booking.setPassengers(passengers);
			// }else {
			//
			// }
			// }

			booking.setPassengers(passengers);
			booking.setPrice_total(passengers.size() * train.getCost_single_seat());

			ticketRepository.save(booking);

			return "Ticket booked successfully";
		} else {
			throw new TicketNotBookedException("Ticket not booked");
		}

	}

	@Override
	public List<Booking> getBooking(int userId) {

		return ticketRepository.getBooking(userId);

	}

}
