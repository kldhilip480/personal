package com.hcl.controller;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.model.Train;
import com.hcl.service.SearchService;

@RestController
public class SearchController {
	@Autowired
	SearchService searchService;
	@GetMapping("/trains/{source}/{destination}")
	public Train getproducts( @PathVariable("source") String source,@PathVariable("destination") String destination) 
		 {
		return searchService.gettrains(source,destination);
	}

}
