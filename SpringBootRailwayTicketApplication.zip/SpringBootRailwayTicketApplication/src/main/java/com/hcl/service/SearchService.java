package com.hcl.service;

import java.sql.Date;

import org.springframework.http.ResponseEntity;

import com.hcl.model.Train;

public interface SearchService {

	

	Train gettrains(String source, String destination);

}
