package com.hcl.serviceimpl;

import org.springframework.stereotype.Service;

import com.hcl.service.UserService;
@Service
public class UserServiceImpl implements UserService{
	
	

}
