package com.hcl.service;

public interface UserService {

}
