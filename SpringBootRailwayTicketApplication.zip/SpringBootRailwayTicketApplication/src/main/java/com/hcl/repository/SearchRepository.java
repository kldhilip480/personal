package com.hcl.repository;

import java.sql.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.model.Train;

@Repository
public interface SearchRepository extends JpaRepository<Train,Integer> {
      
	Train findBySourceAndDestination(String source,String destination);

//	Train findBySourceAndDestinationAndDate(String source, String destination, Date date);
//}
}