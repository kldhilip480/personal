package com.hcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.model.Train;

public interface TrainRepository extends JpaRepository<Train, Integer>{

	Train findByTrainId(int trainId);

}
