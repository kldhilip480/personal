package com.hcl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hcl.model.Booking;

public interface TicketRepository extends JpaRepository<Booking, Integer> {
	
	@Query("from Booking,User u where u.userId =:userId ")
	List<Booking> getBooking(int userId);

}
