package com.hcl.serviceimpl;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.model.Train;
import com.hcl.repository.SearchRepository;
import com.hcl.service.SearchService;

@Service
@Transactional
public class SearchServiceImpl implements SearchService {
	@Autowired
	SearchRepository searchrepo;

	@Override
	public Train gettrains(String source, String destination) {
		return searchrepo.findBySourceAndDestination(source, destination);
	}

	
}
